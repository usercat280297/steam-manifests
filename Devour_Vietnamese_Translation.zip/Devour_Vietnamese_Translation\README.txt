╔════════════════════════════════════════════════════════════════╗
║          DEVOUR - VIETNAMESE TRANSLATION           ║
║                                                                    ║
║ 🇻🇳 Complete Vietnamese localization                               ║
║ ⏰ Created: December 7, 2025                                     ║
║ ✅ Status: Ready to Install                                     ║
╚════════════════════════════════════════════════════════════════╝

📋 CÁCH CÀI ĐẶT (HOW TO INSTALL):

CÁCH 1: TỰ ĐỘNG (AUTOMATIC) ✅ RECOMMENDED
══════════════════════════════════════════

1. Double-click "INSTALL.bat"
2. It will automatically:
   ✅ Find game folder
   ✅ Backup original
   ✅ Install Vietnamese
   ✅ Verify setup

3. Launch game - DONE! 🎮


CÁCH 2: THỦ CÔNG (MANUAL)
══════════════════════════════════════════

1. Find game folder:
   C:\Program Files (x86)\Steam\steamapps\common\Devour

2. Backup original:
   Copy: inventory.json → inventory.json.backup

3. Copy Vietnamese file:
   Copy: inventory.json → game folder

4. Play game - text in TIẾNG VIỆT! ✅


⚠️ IMPORTANT:
══════════════════════════════════════════

✅ Always backup before installing
✅ Backup = easy restore to English
✅ Game won't break
✅ Can uninstall anytime


Game: Devour (AppID: 1274570)
Version: 1.0
Status: READY ✅
═══════════════════════════════════════════
